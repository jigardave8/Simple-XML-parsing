//
//  ViewController.m
//  xml parsing demo
//
//  Created by MAC OS on 21/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import "ViewController.h"
#import "custom.h"
#import "detail.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURL *url=[[NSURL alloc]initWithString:@"http://www.ddservice.ebay.com/feeds/new/xml?siteid=2&count=4"];
    
    NSData *dt=[NSData dataWithContentsOfURL:url];
    
    NSXMLParser *parser1=[[NSXMLParser alloc]initWithData:dt];
    
    parser1.delegate=self;
    
    [parser1 parse];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)parserDidStartDocument:(NSXMLParser *)parser
{
    arr=[[NSMutableArray alloc]init];
    
}

-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    strcontent=[[NSMutableString alloc]initWithString:string];
}
-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDic
{
    if ([elementName isEqualToString:@"ns2:Item"]){
        
        dic=[[NSMutableDictionary alloc]init];
        
    }
    
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    // dic=[[NSMutableDictionary alloc]init];
    
    if ([elementName isEqualToString:@"ItemId"])
    {
        [dic setValue:strcontent forKey:@"ItemId"];
    }
    else if ([elementName isEqualToString:@"DealId"])
    {
        [dic setValue:strcontent forKey:@"DealId"];
    }
    else if ([elementName isEqualToString:@"Title"])
    {
        [dic setValue:strcontent forKey:@"Title"];
    }
    else if ([elementName isEqualToString:@"StartTime"])
    {
        [dic setValue:strcontent forKey:@"StartTime"];
    }
    else if ([elementName isEqualToString:@"EndTime"])
    {
        [dic setValue:strcontent forKey:@"EndTime"];
    }
    else if ([elementName isEqualToString:@"ImageURL"])
    {
        [dic setValue:strcontent forKey:@"ImageURL"];
    }
    
    else if ([elementName isEqualToString:@"DealURL"])
    {
        [dic setValue:strcontent forKey:@"DealURL"];
    }
    
    if ([elementName isEqualToString:@"ns2:Item"])
    {
        [arr addObject:dic];
        dic=[[NSMutableDictionary alloc]init];
    }
}

-(void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"%@",[arr description]);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arr count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    custom *cust=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    NSMutableDictionary *temp=[[NSMutableDictionary alloc]init];
    temp=[arr objectAtIndex:indexPath.row];
    
    cust.lbltitle.text=[temp valueForKey:@"ItemId"];
    
    cust.lblshort.text=[temp valueForKey:@"DealId"];
    
    cust.lblpub.text=[temp valueForKey:@"Title"];
    
    cust.lbllong.text=[temp valueForKey:@"StartTime"];
    
    cust.lblendtime.text=[temp valueForKey:@"EndTime"];
    
    NSString *str=[temp valueForKey:@"ImageURL"];
    
    NSURL *url1=[NSURL URLWithString:str];
    
    NSData *dt1=[NSData dataWithContentsOfURL:url1];
    
   
    cust.imgview.image=[UIImage imageWithData:dt1];
    
    NSString *str1=[temp valueForKey:@"DealURL"];
    NSURL *urlweb=[NSURL URLWithString:str1];
    
    [cust.webview loadRequest:[NSURLRequest requestWithURL:urlweb]];
    
    
  
    
    return cust;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    detail *detail1=[self.storyboard instantiateViewControllerWithIdentifier:@"deta"];
    
    NSUserDefaults *defa=[NSUserDefaults standardUserDefaults];
    
    NSMutableDictionary *dic1=[[NSMutableDictionary alloc]init];
    
    dic1=[arr objectAtIndex:indexPath.row];
    
    [defa setObject:dic1 forKey:@"DealURL"];
    
    [self.navigationController pushViewController:detail1 animated:YES];
}
@end
