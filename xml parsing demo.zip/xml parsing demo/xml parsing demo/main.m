//
//  main.m
//  xml parsing demo
//
//  Created by MAC OS on 21/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
