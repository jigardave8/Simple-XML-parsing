//
//  ViewController.h
//  xml parsing demo
//
//  Created by MAC OS on 21/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *arr;
    NSMutableDictionary *dic;
    
    NSMutableString *strcontent;
}

@end

