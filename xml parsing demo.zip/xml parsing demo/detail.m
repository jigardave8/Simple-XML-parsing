//
//  detail.m
//  xml parsing demo
//
//  Created by MAC OS on 22/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import "detail.h"

@interface detail ()

@end

@implementation detail

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSUserDefaults *defa=[NSUserDefaults standardUserDefaults];
    
    NSMutableDictionary *dic2=[[NSMutableDictionary alloc]init];
    
    dic2= [defa valueForKey:@"DealURL"];
    
    NSString *str1=[dic2 valueForKey:@"DealURL"];
    NSURL *urlweb=[NSURL URLWithString:str1];
    
    [_webdetail loadRequest:[NSURLRequest requestWithURL:urlweb]];
    
       // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
