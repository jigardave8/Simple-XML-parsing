//
//  custom.h
//  xml parsing demo
//
//  Created by MAC OS on 21/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface custom : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lbltitle;
@property (weak, nonatomic) IBOutlet UILabel *lblshort;
@property (weak, nonatomic) IBOutlet UILabel *lblpub;
@property (weak, nonatomic) IBOutlet UILabel *lbllong;
@property (weak, nonatomic) IBOutlet UILabel *lblendtime;
@property (weak, nonatomic) IBOutlet UIImageView *imgview;
@property (weak, nonatomic) IBOutlet UIWebView *webview;

@end
