//
//  detail.h
//  xml parsing demo
//
//  Created by MAC OS on 22/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detail : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webdetail;

@end
