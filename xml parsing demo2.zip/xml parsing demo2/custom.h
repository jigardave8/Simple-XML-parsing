//
//  custom.h
//  xml parsing demo2
//
//  Created by MAC OS on 22/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface custom : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lbltitle;
@property (weak, nonatomic) IBOutlet UILabel *lblshort;
@property (weak, nonatomic) IBOutlet UILabel *lblpub;
@property (weak, nonatomic) IBOutlet UILabel *lbllong;

@end
