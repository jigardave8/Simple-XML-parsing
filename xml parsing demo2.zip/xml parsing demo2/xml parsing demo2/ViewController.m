//
//  ViewController.m
//  xml parsing demo2
//
//  Created by MAC OS on 22/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import "ViewController.h"

#import "custom.h"
#import "detail.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURL *url=[[NSURL alloc]initWithString:@"http://www.divyabhaskar.co.in/rss-feed/4040/"];
    
    NSData *dt=[[NSData alloc]initWithContentsOfURL:url];
    
    NSXMLParser *parser1=[[NSXMLParser alloc]initWithData:dt];
    
    parser1.delegate=self;
    
    [parser1 parse];
    
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
    arr=[[NSMutableArray alloc]init];
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    if ([elementName isEqualToString:@"NewsHeadline"]) {
        dic=[[NSMutableDictionary alloc]init];
    }
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    strcontent=[[NSMutableString alloc]initWithString:string];
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([elementName isEqualToString:@"title"]) {
        [dic setValue:strcontent forKey:@"title"];
    }
    else if ([elementName isEqualToString:@"shortDescription"])
    {
        [dic setValue:strcontent forKey:@"short"];
    }
    
    else if ([elementName isEqualToString:@"description"])
    {
        [dic setValue:strcontent forKey:@"des"];
    }
    else if ([elementName isEqualToString:@"pubDate"])
    {
        [dic setValue:strcontent forKey:@"pub"];
    }
    if ([elementName isEqualToString:@"NewsHeadline"]) {
        [arr addObject:dic];
        dic=[[NSMutableDictionary alloc]init];
    }
}

-(void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"%@",[arr description]);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arr count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    custom *custom=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    NSMutableDictionary *temp=[[NSMutableDictionary alloc]init];
    
    temp=[arr objectAtIndex:indexPath.row];
    
    custom.lbltitle.text=[temp valueForKey:@"title"];
    
    custom.lblshort.text=[temp valueForKey:@"short"];
    
    custom.lblpub.text=[temp valueForKey:@"pub"];
    
    custom.lbllong.text=[temp valueForKey:@"des"];
    
    return custom;
}
-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    detail *next1=[self.storyboard instantiateViewControllerWithIdentifier:@"next"];
    
    NSUserDefaults *defa=[NSUserDefaults standardUserDefaults];
    
    NSMutableDictionary *dic1=[[NSMutableDictionary alloc]init];
    
    dic1=[arr objectAtIndex:indexPath.row];
    
    [defa setObject:dic1 forKey:@"detail"];
    
    [self.navigationController pushViewController:next1 animated:YES];
    
    
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 150;
}
@end
