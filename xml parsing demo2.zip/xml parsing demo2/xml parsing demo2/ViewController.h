//
//  ViewController.h
//  xml parsing demo2
//
//  Created by MAC OS on 22/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSMutableDictionary *dic;
    NSMutableArray *arr;
    NSMutableString *strcontent;
}


@end

