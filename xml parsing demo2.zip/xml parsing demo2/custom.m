//
//  custom.m
//  xml parsing demo2
//
//  Created by MAC OS on 22/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import "custom.h"

@implementation custom

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
