//
//  detail.h
//  xml parsing demo2
//
//  Created by MAC OS on 22/02/1938 SAKA.
//  Copyright (c) 1938 SAKA MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detail : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *txtview;

@end
